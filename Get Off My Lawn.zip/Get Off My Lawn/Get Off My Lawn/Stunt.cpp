#include "Stunt.h"

Stunt::Stunt()
{

}
Stunt::~Stunt()
{

}