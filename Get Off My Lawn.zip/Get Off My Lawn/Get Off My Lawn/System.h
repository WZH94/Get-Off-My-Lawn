#include "AEEngine.h"

#pragma once

void System_Initialise(HINSTANCE instanceH, int show);

void System_Exit();