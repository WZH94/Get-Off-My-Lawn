#include "Saboteur.h"

Saboteur::Saboteur()
{

}
Saboteur::~Saboteur()
{

}