#include "AttackSpeedUp.h"

AttackSpeedUp::AttackSpeedUp()
{

}
AttackSpeedUp::~AttackSpeedUp()
{

}