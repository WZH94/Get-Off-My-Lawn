#include "Tower.h"

#ifndef SWINGING_H
#define SWINGING_H

class Swinging : public Tower
{
private:
	// some code
public:
	// some code
	Swinging();
	~Swinging();
};
#endif SWINGING_H