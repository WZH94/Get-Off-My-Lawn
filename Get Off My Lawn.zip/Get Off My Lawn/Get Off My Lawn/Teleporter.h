#include "Tower.h"

#ifndef TELEPORTER_H
#define TELEPORTER_H

class Teleporter : public Tower
{
private:
	// some code
public:
	// some code
	Teleporter();
	~Teleporter();
};
#endif TELEPORTER_H