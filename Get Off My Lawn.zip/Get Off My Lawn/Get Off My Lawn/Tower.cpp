#include "Tower.h"

Tower::Tower()
{

}
Tower::~Tower()
{

}