#include "Shooter.h"

Shooter::Shooter()
{

}
Shooter::~Shooter()
{

}