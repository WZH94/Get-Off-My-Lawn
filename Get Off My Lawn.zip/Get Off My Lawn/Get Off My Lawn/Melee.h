
#include "Soldier.h"

#ifndef MELEE_H
#define MELEE_H

class Melee : public Soldier
{
private:
	// some code
public:
	// some code
	Melee();
	~Melee();
};
#endif MELEE_H
