#include "Slow.h"

Slow::Slow()
{

}
Slow::~Slow()
{

}