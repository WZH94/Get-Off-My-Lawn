#include "Boss.h"

Boss::Boss()
{

}
Boss::~Boss()
{

}