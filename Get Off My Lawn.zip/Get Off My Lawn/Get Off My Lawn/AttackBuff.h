
#include "AreaOfEffect.h"

#ifndef ATTACKBUFF_H
#define ATTACKBUFF_H

class AttackBuff : public AreaOfEffect
{
private:
	// some code
public:
	// some code
	AttackBuff();
	~AttackBuff();
};
#endif ATTACKBUFF_H
