#include "Soldier.h"

// Default Constructor
Soldier::Soldier()
	// members initialization list
	: 
	speed{},
	cost{},
	side{},
	health{},
	attack_rate{},
	attack_power{}

{
	
}
// Default Destructor
Soldier::~Soldier()
{
}
int const Soldier::Get_Speed()
{
	return speed;
}
void Soldier::Set_Speed(int input_speed)
{
	// some code
	speed = input_speed;
}
int const Soldier::Get_Cost()
{
	return cost;
}
void Soldier::Set_Cost(int input_cost)
{
	// some code
	cost = input_cost;
}
int const Soldier::Get_Side()
{
	return side;
}
void Soldier::Set_Side(int input_side)
{
	// some code
	side = input_side;
}
int const Soldier::Get_Health()
{
	return health;
}
void Soldier::Set_Health(int input_health)
{
	// some code
	health = input_health;
}
int const Soldier::Get_Attack_Rate()
{
	return attack_rate;
}
void Soldier::Set_Attack_Rate(int input_attack_rate)
{
	// some code
	attack_rate = input_attack_rate;
}
int const Soldier::Get_Attack_Power()
{
	return attack_power;
}
void Soldier::Set_Attack_Power(int input_attack_power)
{
	// some code
	attack_power = input_attack_power;
}