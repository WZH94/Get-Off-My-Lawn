#include "Teleporter.h"

Teleporter::Teleporter()
{

}
Teleporter::~Teleporter()
{

}