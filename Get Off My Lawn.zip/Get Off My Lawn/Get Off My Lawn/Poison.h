#include "Tower.h"

#ifndef POISON_H
#define POISON_H

class Poison : public Tower
{
private:
	// some code
public:
	// some code
	Poison();
	~Poison();
};
#endif POISON_H
