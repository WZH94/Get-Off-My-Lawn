#include "Soldier.h"

#ifndef SPEED_H
#define SPEED_H

class Speed : public Soldier
{
private:
	// some code
public:
	// some code
	Speed();
	~Speed();
};
#endif SPEED_H
