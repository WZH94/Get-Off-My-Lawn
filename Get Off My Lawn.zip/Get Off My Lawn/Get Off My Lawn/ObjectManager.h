#include "GameObject.h"

#pragma once

struct ObjectList
{
	ObjectList * next;
	GameObject * gameObject;
};

ObjectList * Create_Object();