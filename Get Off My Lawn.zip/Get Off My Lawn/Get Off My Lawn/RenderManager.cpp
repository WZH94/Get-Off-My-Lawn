#include "RenderManager.h"
#include "AEEngine.h"
#include "GameObject.h"

void Draw_Object(GameObject object)
{
	//// Drawing object 1
	//AEGfxSetRenderMode(AE_GFX_RM_COLOR);
	//// Set position for object 1
	//AEGfxSetPosition(0.0f + object, 0.0f + object1Y);
	//// No texture for object 1
	//AEGfxTextureSet(NULL, 0, 0);
	//// No tint colour
	//AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
	//// Drawing the mesh (list of triangles)
	//AEGfxMeshDraw(pMesh1, AE_GFX_MDM_TRIANGLES);
}