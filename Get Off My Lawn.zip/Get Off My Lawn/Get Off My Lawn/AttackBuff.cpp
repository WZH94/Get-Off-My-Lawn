#include "AttackBuff.h"

AttackBuff::AttackBuff()
{

}
AttackBuff::~AttackBuff()
{

}