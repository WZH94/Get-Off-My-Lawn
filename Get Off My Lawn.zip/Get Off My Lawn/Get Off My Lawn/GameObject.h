#include "AEEngine.h"

#pragma once

class GameObject
{
private:
	AEGfxVertexList * mesh;	// Mesh of the object
	AEGfxTexture * texture;	// Texture of the object
	float x;				// x coordinate of the object
	float y;				// y coordinate of the object
public:
	// Gets the mesh of the object
	AEGfxVertexList * Get_Mesh();
	// Sets the mesh of the object
	void Set_Mesh(AEGfxVertexList * mesh);
	// Gets the texture of the object
	AEGfxTexture * Get_Texture();
	// Sets the texture of the object
	void Set_Texture(AEGfxTexture * texture);
};

enum SIDES
{
	GRANDMA = 0,
	KIDS,
};