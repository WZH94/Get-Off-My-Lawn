
#include "Soldier.h"

#ifndef RANGED_H
#define RANGED_H

class Ranged : public Soldier
{
private:
	// some code
public:
	// some code
	Ranged();
	~Ranged();
};
#endif RANGED_H
