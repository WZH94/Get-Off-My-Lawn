#include "GameObject.h"

#ifndef TOWER_H
#define TOWER_H

class Tower : public GameObject
{
private:
	// some code
public:
	// some code
	Tower();
	~Tower();
};
#endif TOWER_H
