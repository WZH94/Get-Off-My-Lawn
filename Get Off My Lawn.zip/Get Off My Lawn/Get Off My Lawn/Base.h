#ifndef BASE_H
#define BASE_H

class Base
{
private:
	int HP;
	// some code
public:
	// some code
	Base();
	~Base();
	void Base_Update();
	void Base_Draw();
};
#endif BASE_H
