#include "Healer.h"

Healer::Healer()
{

}
Healer::~Healer()
{

}