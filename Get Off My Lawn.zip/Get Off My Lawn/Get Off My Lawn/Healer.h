
#include "Ranged.h"

#ifndef HEALER_H
#define HEALER_H

class Healer : public Ranged
{
private:
	// some code
public:
	// some code
	Healer();
	~Healer();
};
#endif HEALER_H
