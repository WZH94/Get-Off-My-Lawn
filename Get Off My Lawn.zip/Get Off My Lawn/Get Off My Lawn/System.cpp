#include "System.h"
#include "AEEngine.h"

void System_Initialise(HINSTANCE instanceH, int show)
{
	// Initialises Alpha Engine Graphics, Frame Rate and Input managers
	AESysInit(instanceH, show, 1200, 800, 1, 60, NULL);

	AESysSetWindowTitle("Get off my Lawn!");

	AEToogleFullScreen(true);

	// Initialises FMOD
	// Initialises Window size
	/*HWND hwnd = AESysGetWindowHandle();
	HWND hwndDesktopWindow;
	hwndDesktopWindow = GetForegroundWindow();
	RECT   rectScreen;
	int    WindowPosX;
	int    WindowPosY;
	GetWindowRect(hwndDesktopWindow, &rectScreen);
	SetWindowPos(hwnd, NULL, 0, 0, 1000, 500, SWP_SHOWWINDOW);*/
}

void System_Exit()
{
	AESysExit();

	// Release FMOD
}