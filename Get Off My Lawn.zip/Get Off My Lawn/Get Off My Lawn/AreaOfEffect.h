
#include "Soldier.h"

#ifndef AREAOFEFFECT_H
#define AREAOFEFFECT_H

class AreaOfEffect : public Soldier
{
private:
	// some code
public:
	// some code
	AreaOfEffect();
	~AreaOfEffect();
};
#endif AREAOFEFFECT_H
