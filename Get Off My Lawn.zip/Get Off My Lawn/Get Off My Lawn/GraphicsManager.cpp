#include "AEEngine.h"
#include "GraphicsManager.h"

AEGfxTexture * Texture_Load(const char * texture)
{
	AEGfxTexture * pTex = nullptr;

	pTex = AEGfxTextureLoad(texture);

	return pTex;
}

AEGfxVertexList * Mesh_Load_Square()
{
	AEGfxVertexList * pMesh = nullptr;

	AEGfxMeshStart();

	AEGfxTriAdd(
		-30.0f, -30.0f, 0x00FF00FF, 0.0f, 1.0f,
		30.0f, -30.0f, 0x00FFFF00, 0.0f, 1.0f,
		-30.0f, 30.0f, 0x0000FFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		30.0f, -30.0f, 0x00FFFFFF, 0.0f, 1.0f,
		30.0f, 30.0f, 0x00FFFFFF, 0.0f, 0.0f,
		-30.0f, 30.0f, 0x00FFFFFF, 0.0f, 0.0f);

	pMesh = AEGfxMeshEnd();
	//AE_ASSERT_MESG(pMesh, "Failed to create mesh!!");

	return pMesh;
}

void Texture_Unload(AEGfxTexture * pTex)
{
	AEGfxTextureUnload(pTex);
}