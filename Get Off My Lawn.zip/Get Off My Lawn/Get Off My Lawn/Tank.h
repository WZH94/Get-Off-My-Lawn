
#include "Melee.h"

#ifndef TANK_H
#define TANK_H

class Tank : public Melee
{
private:
	// some code
public:
	// some code
	Tank();
	~Tank();
};
#endif TANK_H
