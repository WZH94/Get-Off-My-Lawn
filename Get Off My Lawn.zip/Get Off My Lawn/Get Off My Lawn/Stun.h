
#include "AreaOfEffect.h"

#ifndef STUN_H
#define STUN_H

class Stun : public AreaOfEffect
{
private:
	// some code
public:
	// some code
	Stun();
	~Stun();
};
#endif STUN_H
