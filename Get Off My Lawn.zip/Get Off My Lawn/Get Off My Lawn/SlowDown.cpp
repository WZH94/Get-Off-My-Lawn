#include "SlowDown.h"

SlowDown::SlowDown()
{

}
SlowDown::~SlowDown()
{

}