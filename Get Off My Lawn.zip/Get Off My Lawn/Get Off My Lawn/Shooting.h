#include "Tower.h"

#ifndef SHOOTING_H
#define SHOOTING_H

class Shooting : public Tower
{
private:
	// some code
public:
	// some code
	Shooting();
	~Shooting();
};
#endif SHOOTING_H
