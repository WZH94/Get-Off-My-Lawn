#include "Poison.h"

Poison::Poison()
{

}
Poison::~Poison()
{

}