#pragma once

void Level1_Load();

void Level1_Init();

void Level1_Update();

void Level1_Draw();

void Level1_Free();

void Level1_Unload();