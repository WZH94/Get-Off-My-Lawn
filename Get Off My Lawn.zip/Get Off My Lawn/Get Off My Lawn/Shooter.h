
#include "Ranged.h"

#ifndef SHOOTER_H
#define SHOOTER_H

class Shooter : public Ranged
{
private:
	// some code
public:
	// some code
	Shooter();
	~Shooter();
};
#endif SHOOTER_H