#pragma once

typedef void(*GS)(void);

extern GS GSLoad, GSInit, GSUpdate, GSDraw, GSFree, GSUnload;

void GameStateManager_Initialise();