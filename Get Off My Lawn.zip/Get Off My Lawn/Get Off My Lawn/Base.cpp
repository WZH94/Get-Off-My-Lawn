#include "Base.h"

Base::Base()
	:HP {50}
{
	
}
Base::~Base()
{

}

void Base::Base_Update()
{

}
