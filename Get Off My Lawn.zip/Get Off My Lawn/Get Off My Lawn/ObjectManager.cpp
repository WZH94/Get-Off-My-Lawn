#include "ObjectManager.h"
#include "GameObject.h"

ObjectList * Create_Object()
{
	ObjectList * pObject = new ObjectList;

	return pObject;
}

void Free_Object(ObjectList ** ppObject)
{
	
}