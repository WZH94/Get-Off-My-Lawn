#include "AreaOfEffect.h"

AreaOfEffect::AreaOfEffect()
{

}
AreaOfEffect::~AreaOfEffect()
{

}