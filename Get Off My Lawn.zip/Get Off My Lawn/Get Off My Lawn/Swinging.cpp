#include "Swinging.h"

Swinging::Swinging()
{

}
Swinging::~Swinging()
{

}