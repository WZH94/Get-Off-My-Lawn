#include "Ranged.h"

Ranged::Ranged()
{
	
}
Ranged::~Ranged()
{
	
}