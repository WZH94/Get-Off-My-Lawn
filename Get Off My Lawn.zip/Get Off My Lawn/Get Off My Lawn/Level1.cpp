#include "Level1.h"
#include "ObjectManager.h"
#include "GraphicsManager.h"

// Loads and initialises all object data
void Level1_Load()
{
	// Load textures
	//AEGfxTexture * CookieGrandma = Texture_Load("");
	// Load AI
	//Set background colour
	AEGfxSetBackgroundColor(0.0f, 0.4f, 0.0f);
	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
}

// Sets object data instances within the level and fills object list
void Level1_Init()
{

}

void Level1_Update()
{
	u32 fontID = 0;

	//////////////////////////////////
	// Creating Fonts	
	fontID = AEGfxCreateFont("Courier New", 24, true, false);
	// Creating Fonts end
	//////////////////////////////////
	char strBuffer[100];
	memset(strBuffer, 0, 100 * sizeof(char));
	sprintf_s(strBuffer, "Frame Time:  %.6f", AEFrameRateControllerGetFrameTime());

	AEGfxSetRenderMode(AE_GFX_RM_COLOR);
	AEGfxTextureSet(NULL, 0, 0);
	AEGfxSetTransparency(1.0f);
	AEGfxPrint(fontID, strBuffer, -580, 375, 0.30078125f, 0.1484375f, 0.0f);


}

void Level1_Draw()
{
	AEGfxTexture *pRoute = nullptr;

	AEGfxVertexList *pMesh2 = nullptr;
	// Informing the library that we're about to start adding triangles
	AEGfxMeshStart();

	// This shape has 2 triangles
	AEGfxTriAdd(
		-30.0f, -30.0f, 0x00FF00FF, 0.0f, 1.0f,
		30.0f, -30.0f, 0x00FFFF00, 1.0f, 1.0f,
		-30.0f, 30.0f, 0x0000FFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		30.0f, -30.0f, 0x00FFFFFF, 1.0f, 1.0f,
		30.0f, 30.0f, 0x00FFFFFF, 1.0f, 0.0f,
		-30.0f, 30.0f, 0x00FFFFFF, 0.0f, 0.0f);

	// Saving the mesh (list of triangles) in pMesh2

	pMesh2 = AEGfxMeshEnd();
	AE_ASSERT_MESG(pMesh2, "Failed to create mesh 2!!");

	pRoute = AEGfxTextureLoad("Resources/rock_path.png");
	AE_ASSERT_MESG(pRoute, "Failed to load rock path texture!!");

	// Drawing object 3 - (Second) - Blue tint
	AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
	//AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	// Set position for object 3
	AEGfxSetPosition(100.0f, 60.0f);
	// Add Blue tint
	AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
	// Set texture
	AEGfxTextureSet(pRoute, 0, 0);
	//set transparency
	AEGfxSetTransparency(1.0f);
	// Drawing the mesh (list of triangles)
	AEGfxMeshDraw(pMesh2, AE_GFX_MDM_TRIANGLES);

}

void Level1_Free()
{

}

void Level1_Unload()
{
	//AEGfxTextureUnload(pRoute);
}