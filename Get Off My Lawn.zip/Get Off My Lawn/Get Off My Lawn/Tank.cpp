#include "Tank.h"

Tank::Tank()
{

}
Tank::~Tank()
{

}