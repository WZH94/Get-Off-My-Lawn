#pragma once

enum GS_STATES
{
	GS_LEVEL_1 = 0,
	GS_LEVEL_2,
};