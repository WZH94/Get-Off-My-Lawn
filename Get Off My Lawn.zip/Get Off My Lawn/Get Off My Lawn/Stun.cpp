#include "Stun.h"

Stun::Stun()
{

}
Stun::~Stun()
{

}