
#include "Ranged.h"

#ifndef SABOTEUR_H
#define SABOTEUR_H

class Saboteur : public Ranged
{
private:
	// some code
public:
	// some code
	Saboteur();
	~Saboteur();
};
#endif SABOTEUR_H
