#include "GameObject.h"
#include "Soldier.h"
#include "AEEngine.h"

// Gets the mesh of the object
AEGfxVertexList * GameObject::Get_Mesh()
{
	return mesh;
}
// Sets the mesh of the object
void GameObject::Set_Mesh(AEGfxVertexList * mesh)
{

}
// Gets the texture of the object
AEGfxTexture * GameObject::Get_Texture()
{
	return texture;
}
// Sets the texture of the object
void GameObject::Set_Texture(AEGfxTexture * texture)
{

}