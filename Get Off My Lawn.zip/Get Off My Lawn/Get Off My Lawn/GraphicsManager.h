#include "AEEngine.h"

#pragma once

AEGfxTexture * Texture_Load(const char * texture);