#include "GameObject.h"

#ifndef SOLDIER_H
#define SOLDIER_H

enum SOLDIER_TYPE
{
	NORMAL = 0,
	FLANKER,
	ANTIFLANK,
	SUPPORT
};

class Soldier : public GameObject
{
private:
	int speed; // movement speed of soldiers
	int cost; // the cost to purchase a soldier (available for player only)
	int side; // enemy or player side
	int health; // the health point of a soldier
	int attack_rate; // the attack speed/rate of a soldier
	int attack_power; // the attack power of a soldier (e.g. dmg/s)

public:
	// default constructor
	Soldier();
	// default destructor
	~Soldier();
	// gets the speed of the soldier
	int const Get_Speed();
	// set the speed of the soldier
	void Set_Speed(int);
	// get the cost of the soldier
	int const Get_Cost();
	// set the cost of the soldier
	void Set_Cost(int);
	// get the side of the soldier
	int const Get_Side();
	// set the side of the soldier
	void Set_Side(int);
	// get the health of the soldier
	int const Get_Health();
	// set the health of the soldier
	void Set_Health(int);
	// get the attack rate of the soldier
	int const Get_Attack_Rate();
	// set the attack rate of the soldier
	void Set_Attack_Rate(int);
	// get the attack power of the soldier
	int const Get_Attack_Power();
	// set the attack power of the soldier
	void Set_Attack_Power(int);
};
#endif SOLDIER_H