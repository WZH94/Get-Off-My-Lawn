#include "Tower.h"

#ifndef STUNT_H
#define STUNT_H

class Stunt : public Tower
{
private:
	// some code
public:
	// some code
	Stunt();
	~Stunt();
};
#endif STUNT_H
