#include "AEEngine.h"
#include "System.h"
#include "GameStateManager.h"
#include <iostream>

int WINAPI WinMain(HINSTANCE instanceH, HINSTANCE prevInstanceH, LPSTR command_line, int show)
{
	// Initialises all system components
	System_Initialise(instanceH, show);

	// Adds every game state in the game and initialises Game State Manager
	GameStateManager_Initialise();

	// Game State Loop
	while (gAEGameStateCurr != AE_GS_QUIT)
	{
		if (gAEGameStateCurr == AE_GS_RESTART)
		{
			gAEGameStateCurr = gAEGameStatePrev;
			gAEGameStateNext = gAEGameStatePrev;
		}

		else
		{
			AEGameStateMgrUpdate();
			AEGameStateLoad();
		}

		AEGameStateInit();

		// Game Loop
		while (gAEGameStateCurr == gAEGameStateNext)
		{
			AESysFrameStart();
			// INPUT HANDLER
			AEGameStateUpdate();
			AEGameStateDraw();
			AESysFrameEnd();
			break;
		}

		AEGameStateFree();

		if (gAEGameStateNext != AE_GS_RESTART)
			AEGameStateUnload();

		gAEGameStatePrev = gAEGameStateCurr;
		gAEGameStateCurr = gAEGameStateNext;

		//break;
	}

	System_Exit();
}