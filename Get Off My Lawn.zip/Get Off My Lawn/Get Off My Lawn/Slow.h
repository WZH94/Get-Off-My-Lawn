
#include "Ranged.h"

#ifndef SLOW_H
#define SLOW_H

class Slow : public Ranged
{
private:
	// some code
public:
	// some code
	Slow();
	~Slow();
};
#endif SLOW_H