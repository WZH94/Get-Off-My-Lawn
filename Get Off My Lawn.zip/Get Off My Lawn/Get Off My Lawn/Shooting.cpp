#include "Shooting.h"

Shooting::Shooting()
{

}
Shooting::~Shooting()
{

}