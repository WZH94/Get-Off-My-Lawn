
#include "Soldier.h"

#ifndef BOSS_H
#define BOSS_H

class Boss : public Soldier
{
private:
	// some code
public:
	// some code
	Boss();
	~Boss();
};
#endif BOSS_H
