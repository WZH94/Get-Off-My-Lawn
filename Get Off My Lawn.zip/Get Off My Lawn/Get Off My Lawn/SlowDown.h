#include "Tower.h"

#ifndef SLOWDOWN_H
#define SLOWDOWN_H

class SlowDown : public Tower
{
private:
	// some code
public:
	// some code
	SlowDown();
	~SlowDown();
};
#endif SLOWDOWN_H