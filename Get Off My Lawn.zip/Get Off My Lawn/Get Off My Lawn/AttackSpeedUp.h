
#include "Melee.h"

#ifndef ATTACKSPEEDUP_H
#define ATTACKSPEEDUP_H

class AttackSpeedUp : public Melee
{
private:
	// some code
public:
	// some code
	AttackSpeedUp();
	~AttackSpeedUp();
};
#endif ATTACKSPEEDUP_H
