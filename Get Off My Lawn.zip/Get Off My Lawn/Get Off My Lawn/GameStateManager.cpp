#include "GameStateManager.h"
#include "GameStateList.h"
#include "Level1.h"
#include "AEEngine.h"

void GameStateManager_Initialise()
{
	// Adds all the game states to the Game State Manager before initialising it
	AEGameStateMgrAdd(GS_LEVEL_1, Level1_Load, Level1_Init, Level1_Update, Level1_Draw, Level1_Free, Level1_Unload);

	// Initialises Game State Manager with the first game state to load up
	AEGameStateMgrInit(GS_LEVEL_1);
}