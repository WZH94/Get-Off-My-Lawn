#include "Speed.h"

Speed::Speed()
{

}
Speed::~Speed()
{

}